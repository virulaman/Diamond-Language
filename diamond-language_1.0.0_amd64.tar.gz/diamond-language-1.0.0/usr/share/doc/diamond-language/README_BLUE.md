# Blue Package Manager for Diamond Language

The **Blue** package manager is a comprehensive module management system for the Diamond Programming Language, providing easy installation, search, and upload of Diamond modules and extensions.

## 🎉 What's New: Complete Package Ecosystem!

Blue provides a complete package management solution that allows you to:
- **Install modules** with simple commands
- **Search** the module registry  
- **Upload** your own .c extensions
- **Manage** dependencies automatically

## ✨ Features

### Package Installation
```bash
blue install <module>     # Install any Diamond module
blue install audio        # Install audio processing module
blue install gamedev      # Install game development toolkit
blue install crypto       # Install cryptography functions
```

### Module Discovery
```bash
blue search <query>       # Search for modules
blue search audio         # Find audio-related modules
blue search game          # Find game development modules
blue list                 # List all installed modules
```

### Module Information
```bash
blue info <module>        # Get detailed module information
blue info gamedev         # Show gamedev functions and details
```

### Extension Upload
```bash
blue upload <file.c>      # Upload your .c extension to registry
blue upload my_extension.c
```

## 🎁 Surprise Modules Included

### 1. 🎵 Audio Module
Advanced audio processing for Diamond
- `play_sound(filename)` - Play audio files
- `generate_tone(frequency, duration)` - Generate pure tones
- `set_volume(level)` - Control audio volume

### 2. 🎮 Game Development Module  
Complete game development toolkit
- `create_sprite(x, y, width, height)` - Create game sprites
- `move_sprite(id, vel_x, vel_y)` - Move sprites with physics
- `check_collision(sprite1, sprite2)` - Collision detection
- `apply_gravity(sprite, force)` - Physics simulation

### 3. 🔐 Cryptography Module
Security and encryption functions
- `hash_sha256(data)` - Generate SHA-256 hashes
- `encrypt_simple(data, key)` - Simple encryption
- `generate_random(length)` - Random string generation

### 4. 🌐 Network Module
TCP/UDP networking capabilities
- `tcp_connect(host, port)` - Connect to TCP servers
- `tcp_listen(port)` - Start TCP servers
- `udp_send(data, host, port)` - Send UDP packets

### 5. 🧠 AI Module
Machine learning and neural networks
- `create_network(input, hidden, output)` - Create neural networks
- `train_model(data)` - Train ML models
- `predict(input)` - Make predictions

### 6. 🗄️ Database Module
Database connectivity and operations
- `db_connect(connection_string)` - Connect to databases
- `db_query(sql)` - Execute SQL queries
- `db_close(connection)` - Close connections

## 🚀 Quick Start

### Installation
```bash
# Install Blue package manager
./install_blue.sh

# Add to PATH (optional)
export PATH="$PATH:$(pwd)"
```

### Using Blue (Demo Mode)
```bash
# Show available modules
python blue_demo.py

# Install modules
python blue_demo.py install audio
python blue_demo.py install gamedev

# Search for modules
python blue_demo.py search crypto

# Get module information
python blue_demo.py info gamedev

# List installed modules
python blue_demo.py list

# Upload your extension
python blue_demo.py upload my_extension.c
```

## 📝 Using Modules in Diamond Code

```diamond
// Audio example
use stdlib;
use audio;

int main() {
    play_sound("music.wav");
    generate_tone(440.0, 2.0);  // A note for 2 seconds
    set_volume(0.8);
    return 0;
}
```

```diamond
// Game development example
use stdlib;
use gamedev;

int main() {
    int player = create_sprite(100, 100, 32, 32);
    int enemy = create_sprite(200, 150, 24, 24);
    
    move_sprite(player, 5, 0);
    apply_gravity(player, 0.5);
    
    if (check_collision(player, enemy)) {
        show.txt("Collision detected!");
    }
    
    return 0;
}
```

## 🔧 API Backend

Blue includes a complete RESTful API for module management:

- **GET** `/api/modules` - List all modules
- **GET** `/api/modules/{name}` - Get module details
- **GET** `/api/search?q={query}` - Search modules
- **POST** `/api/upload` - Upload new extensions
- **GET** `/api/download/{module}/{file}` - Download module files

## 📁 Project Structure

```
📦 Blue Package Manager
├── blue_package_manager.py     # Main CLI tool
├── blue_demo.py               # Demo version (works offline)
├── diamond_registry_api.py    # RESTful API server
├── install_blue.sh           # Installation script
├── modules/                  # Downloaded modules
│   ├── audio.c
│   ├── gamedev.c
│   └── crypto.c
└── extensions/              # Uploaded extensions
    └── example_extension.c
```

## 🌟 Why Blue?

- **Complete Ecosystem**: Everything you need for Diamond development
- **Easy Installation**: One command installs any module
- **Community Driven**: Upload and share your own extensions
- **Professional Modules**: High-quality, tested modules included
- **Dependency Management**: Automatic dependency resolution
- **Rich Discovery**: Search, browse, and explore modules
- **Offline Demo**: Works without internet connection

## 🎯 Diamond + Blue = Complete Programming Experience

Diamond provides the language syntax and core features, while Blue provides the rich ecosystem of modules and extensions. Together, they create a complete, modern programming experience with:

- **Language**: Diamond's C#-like syntax with C structure
- **Graphics**: Built-in SVG graphics with collision detection
- **Packages**: Blue's comprehensive module system
- **Community**: Extension sharing and collaboration

Blue makes Diamond not just a language, but a complete development platform!