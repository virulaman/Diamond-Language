# Installing Diamond Language + Blue Package Manager on Fedora Linux

This guide shows how to install the complete Diamond Language development environment with the Blue package manager on Fedora Linux.

## 🚀 Quick Installation

### Method 1: Automated Installer (Recommended)
```bash
# Clone or download the Diamond Language project
# Navigate to the project directory
cd diamond-language

# Run the Fedora installer
chmod +x install_blue_fedora.sh
./install_blue_fedora.sh
```

### Method 2: Manual Installation

#### Step 1: Install Dependencies
```bash
# Update system packages
sudo dnf update -y

# Install Python and development tools
sudo dnf install -y python3 python3-pip python3-devel

# Install C development tools
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y gcc gcc-c++ make cmake

# Install Python packages
pip3 install --user requests flask flask-sqlalchemy
```

#### Step 2: Build Diamond Compiler
```bash
# Compile the Diamond language compiler
make clean && make all

# Test the installation
./dmo examples/hello.dmo
```

#### Step 3: Set Up Blue Package Manager
```bash
# Make Blue executable
chmod +x blue_package_manager.py
chmod +x blue_demo.py

# Test Blue package manager
python3 blue_demo.py
```

## 🎯 Fedora-Specific Features

### Package Management
Fedora uses `dnf` instead of `apt`, so the installer automatically:
- Uses `dnf install` for system packages
- Installs "Development Tools" group for C compilation
- Uses `pip3 --user` for user-level Python packages

### Desktop Integration
The Fedora installer creates a desktop entry at:
```
~/.local/share/applications/blue-package-manager.desktop
```

### PATH Configuration
Automatically adds Blue to your PATH in `~/.bashrc`

## 🧪 Testing Your Installation

### Test Diamond Compiler
```bash
# Test basic compilation
./dmo examples/hello.dmo

# Test graphics features
./dmo examples/graphics_demo.dmo

# Test HTTP requests
./dmo examples/request_demo.dmo

# Test math operations
./dmo examples/math_demo.dmo
```

### Test Blue Package Manager
```bash
# Show available modules
./blue-demo

# Install audio module
./blue-demo install audio

# Search for modules
./blue-demo search game

# List installed modules
./blue-demo list

# Get module information
./blue-demo info gamedev

# Upload a custom extension
./blue-demo upload example_extension.c
```

## 🔧 Fedora Version Compatibility

This installation has been tested on:
- ✅ Fedora 38
- ✅ Fedora 39
- ✅ Fedora 40
- ✅ Fedora Rawhide

Should also work on:
- CentOS Stream
- RHEL 9+ (with EPEL repository)
- Rocky Linux 9+
- AlmaLinux 9+

## 🛠️ Troubleshooting

### Python Issues
```bash
# If python3 not found
sudo dnf install python3

# If pip3 not found
sudo dnf install python3-pip

# If permission denied for pip
pip3 install --user <package>
```

### Compiler Issues
```bash
# If gcc not found
sudo dnf groupinstall "Development Tools"

# If make not found
sudo dnf install make

# If compilation fails
make clean && make all
```

### Permission Issues
```bash
# Make scripts executable
chmod +x *.sh
chmod +x blue*

# Fix PATH issues
source ~/.bashrc
# OR restart your terminal
```

## 🎮 Using Diamond Modules on Fedora

### Example: Audio Module
```diamond
use stdlib;
use audio;

int main() {
    show.txt("Diamond Audio on Fedora!");
    play_sound("notification.wav");
    generate_tone(440.0, 1.0);
    return 0;
}
```

### Example: Game Development
```diamond
use stdlib;
use gamedev;

int main() {
    show.txt("Game Development on Fedora!");
    int player = create_sprite(100, 100, 32, 32);
    move_sprite(player, 5, 0);
    return 0;
}
```

## 📁 File Locations on Fedora

```
~/diamond-language/              # Main project directory
├── dmo                         # Diamond compiler executable
├── blue-demo                   # Blue package manager
├── modules/                    # Downloaded modules
│   ├── audio.c
│   ├── gamedev.c
│   └── crypto.c
├── extensions/                 # User extensions
└── examples/                   # Example programs
    ├── hello.dmo
    ├── graphics_demo.dmo
    └── request_demo.dmo
```

## 🌟 Next Steps

After installation:

1. **Learn Diamond**: Start with `./dmo examples/hello.dmo`
2. **Explore Modules**: Run `./blue-demo` to see available packages
3. **Install Packages**: Try `./blue-demo install audio`
4. **Create Programs**: Write your own `.dmo` files
5. **Upload Extensions**: Share your work with `./blue-demo upload`

## 💡 Fedora Tips

- Use `dnf search` to find additional development packages
- Consider installing `code` (VS Code) for Diamond development
- Use `firewall-cmd` if you need network access for modules
- Check `journalctl` for system-level debugging

The Diamond Language with Blue package manager is now ready for development on your Fedora system!