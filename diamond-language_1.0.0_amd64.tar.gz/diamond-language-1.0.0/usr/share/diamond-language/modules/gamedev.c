/*
 * Diamond Game Development Module
 * Comprehensive game development toolkit
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "../interpreter.h"

// Game object structure
typedef struct {
    int id;
    double x, y;
    double width, height;
    double vel_x, vel_y;
    int active;
} GameObject;

static GameObject game_objects[100];
static int next_object_id = 1;

Value gamedev_create_sprite(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 4) {
        fprintf(stderr, "Error: create_sprite requires x, y, width, height\n");
        return create_number_value(-1);
    }
    
    Value x = execute_node(args[0], ctx);
    Value y = execute_node(args[1], ctx);
    Value w = execute_node(args[2], ctx);
    Value h = execute_node(args[3], ctx);
    
    // Create new game object
    int id = next_object_id++;
    GameObject* obj = &game_objects[id % 100];
    obj->id = id;
    obj->x = x.number;
    obj->y = y.number;
    obj->width = w.number;
    obj->height = h.number;
    obj->vel_x = 0;
    obj->vel_y = 0;
    obj->active = 1;
    
    printf("🎮 Created sprite #%d at (%.0f,%.0f) size %.0fx%.0f\n", 
           id, x.number, y.number, w.number, h.number);
    
    free_value(x);
    free_value(y);
    free_value(w);
    free_value(h);
    
    return create_number_value(id);
}

Value gamedev_move_sprite(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 3) {
        fprintf(stderr, "Error: move_sprite requires sprite_id, vel_x, vel_y\n");
        return create_void_value();
    }
    
    Value id = execute_node(args[0], ctx);
    Value vel_x = execute_node(args[1], ctx);
    Value vel_y = execute_node(args[2], ctx);
    
    GameObject* obj = &game_objects[(int)id.number % 100];
    if (obj->active && obj->id == (int)id.number) {
        obj->vel_x = vel_x.number;
        obj->vel_y = vel_y.number;
        obj->x += obj->vel_x;
        obj->y += obj->vel_y;
        
        printf("🏃 Sprite #%d moved to (%.0f,%.0f) velocity (%.0f,%.0f)\n", 
               obj->id, obj->x, obj->y, obj->vel_x, obj->vel_y);
    }
    
    free_value(id);
    free_value(vel_x);
    free_value(vel_y);
    
    return create_void_value();
}

Value gamedev_check_collision(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 2) {
        fprintf(stderr, "Error: check_collision requires two sprite IDs\n");
        return create_number_value(0);
    }
    
    Value id1 = execute_node(args[0], ctx);
    Value id2 = execute_node(args[1], ctx);
    
    GameObject* obj1 = &game_objects[(int)id1.number % 100];
    GameObject* obj2 = &game_objects[(int)id2.number % 100];
    
    int collision = 0;
    if (obj1->active && obj2->active && 
        obj1->id == (int)id1.number && obj2->id == (int)id2.number) {
        
        // AABB collision detection
        if (obj1->x < obj2->x + obj2->width &&
            obj1->x + obj1->width > obj2->x &&
            obj1->y < obj2->y + obj2->height &&
            obj1->y + obj1->height > obj2->y) {
            collision = 1;
            printf("💥 Collision detected between sprites #%d and #%d\n", 
                   obj1->id, obj2->id);
        }
    }
    
    free_value(id1);
    free_value(id2);
    
    return create_number_value(collision);
}

Value gamedev_apply_gravity(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 2) {
        fprintf(stderr, "Error: apply_gravity requires sprite_id and gravity_force\n");
        return create_void_value();
    }
    
    Value id = execute_node(args[0], ctx);
    Value gravity = execute_node(args[1], ctx);
    
    GameObject* obj = &game_objects[(int)id.number % 100];
    if (obj->active && obj->id == (int)id.number) {
        obj->vel_y += gravity.number;
        obj->y += obj->vel_y;
        
        printf("🌍 Applied gravity %.2f to sprite #%d\n", gravity.number, obj->id);
    }
    
    free_value(id);
    free_value(gravity);
    
    return create_void_value();
}

// Game development module initialization
void init_gamedev_module(InterpreterContext* ctx) {
    printf("Diamond Game Development Module loaded\n");
    
    // Initialize game objects
    for (int i = 0; i < 100; i++) {
        game_objects[i].active = 0;
    }
    
    // Register game development functions
    register_function("create_sprite", gamedev_create_sprite, ctx);
    register_function("move_sprite", gamedev_move_sprite, ctx);
    register_function("check_collision", gamedev_check_collision, ctx);
    register_function("apply_gravity", gamedev_apply_gravity, ctx);
}