/*
 * Diamond Audio Module
 * Advanced audio playback and generation for Diamond language
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "../interpreter.h"

// Audio module functions
Value audio_play_sound(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 1) {
        fprintf(stderr, "Error: play_sound requires filename\n");
        return create_void_value();
    }
    
    Value filename = execute_node(args[0], ctx);
    printf("🎵 Playing sound: %s\n", filename.string);
    
    // Simulate audio playback with system command
    char command[512];
    snprintf(command, sizeof(command), "echo 'Playing audio file: %s'", filename.string);
    system(command);
    
    free_value(filename);
    return create_void_value();
}

Value audio_generate_tone(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 2) {
        fprintf(stderr, "Error: generate_tone requires frequency and duration\n");
        return create_void_value();
    }
    
    Value freq = execute_node(args[0], ctx);
    Value duration = execute_node(args[1], ctx);
    
    printf("🎶 Generating tone: %.2fHz for %.2fs\n", freq.number, duration.number);
    
    // Generate simple sine wave data
    int sample_rate = 44100;
    int num_samples = (int)(duration.number * sample_rate);
    
    printf("Generated %d samples at %.2fHz\n", num_samples, freq.number);
    
    free_value(freq);
    free_value(duration);
    return create_void_value();
}

Value audio_set_volume(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 1) {
        fprintf(stderr, "Error: set_volume requires volume level (0.0-1.0)\n");
        return create_void_value();
    }
    
    Value volume = execute_node(args[0], ctx);
    printf("🔊 Setting volume to: %.2f\n", volume.number);
    
    free_value(volume);
    return create_void_value();
}

// Audio module initialization
void init_audio_module(InterpreterContext* ctx) {
    printf("Diamond Audio Module loaded\n");
    
    // Register audio functions
    register_function("play_sound", audio_play_sound, ctx);
    register_function("generate_tone", audio_generate_tone, ctx);
    register_function("set_volume", audio_set_volume, ctx);
}