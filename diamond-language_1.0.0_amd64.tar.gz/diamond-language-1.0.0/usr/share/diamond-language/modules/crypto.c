/*
 * Diamond Cryptography Module
 * Encryption, hashing, and security functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "../interpreter.h"

// Simple hash function (demonstration)
unsigned long djb2_hash(const char* str) {
    unsigned long hash = 5381;
    int c;
    while ((c = *str++)) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}

Value crypto_hash_sha256(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 1) {
        fprintf(stderr, "Error: hash_sha256 requires data string\n");
        return create_string_value("");
    }
    
    Value data = execute_node(args[0], ctx);
    
    // Simple demonstration hash (not real SHA-256)
    unsigned long hash = djb2_hash(data.string);
    char hash_str[65];
    snprintf(hash_str, sizeof(hash_str), "%08lx%08lx%08lx%08lx", 
             hash, hash ^ 0xAAAAAAAA, hash ^ 0x55555555, hash ^ 0xFFFFFFFF);
    
    printf("🔐 Generated hash for: %s\n", data.string);
    printf("📋 SHA-256: %s\n", hash_str);
    
    free_value(data);
    return create_string_value(hash_str);
}

Value crypto_encrypt_simple(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 2) {
        fprintf(stderr, "Error: encrypt_simple requires data and key\n");
        return create_string_value("");
    }
    
    Value data = execute_node(args[0], ctx);
    Value key = execute_node(args[1], ctx);
    
    // Simple XOR encryption for demonstration
    int data_len = strlen(data.string);
    int key_len = strlen(key.string);
    char* encrypted = malloc(data_len * 2 + 1);
    
    for (int i = 0; i < data_len; i++) {
        char encrypted_char = data.string[i] ^ key.string[i % key_len];
        sprintf(encrypted + (i * 2), "%02x", (unsigned char)encrypted_char);
    }
    encrypted[data_len * 2] = '\0';
    
    printf("🔒 Encrypted data with key: %s\n", key.string);
    printf("📋 Encrypted: %s\n", encrypted);
    
    Value result = create_string_value(encrypted);
    free(encrypted);
    free_value(data);
    free_value(key);
    
    return result;
}

Value crypto_generate_random(ASTNode** args, int arg_count, InterpreterContext* ctx) {
    if (arg_count != 1) {
        fprintf(stderr, "Error: generate_random requires length\n");
        return create_string_value("");
    }
    
    Value length = execute_node(args[0], ctx);
    int len = (int)length.number;
    
    if (len <= 0 || len > 1000) {
        fprintf(stderr, "Error: Invalid length for random generation\n");
        free_value(length);
        return create_string_value("");
    }
    
    char* random_str = malloc(len + 1);
    const char* charset = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    
    srand(time(NULL));
    for (int i = 0; i < len; i++) {
        random_str[i] = charset[rand() % 62];
    }
    random_str[len] = '\0';
    
    printf("🎲 Generated random string of length %d\n", len);
    printf("📋 Random: %s\n", random_str);
    
    Value result = create_string_value(random_str);
    free(random_str);
    free_value(length);
    
    return result;
}

// Cryptography module initialization
void init_crypto_module(InterpreterContext* ctx) {
    printf("Diamond Cryptography Module loaded\n");
    
    // Register crypto functions
    register_function("hash_sha256", crypto_hash_sha256, ctx);
    register_function("encrypt_simple", crypto_encrypt_simple, ctx);
    register_function("generate_random", crypto_generate_random, ctx);
}