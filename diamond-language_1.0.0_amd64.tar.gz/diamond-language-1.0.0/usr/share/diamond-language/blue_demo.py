#!/usr/bin/env python3
"""
Blue Package Manager Demo - Works without network connection
Demonstrates the Blue package manager functionality locally
"""

import sys
import os
import json
from pathlib import Path

# Local module registry for demo
LOCAL_MODULES = {
    'audio': {
        'name': 'audio',
        'version': '1.0.0',
        'description': '🎵 Diamond Audio Library - Play sounds, generate tones, and create music',
        'author': 'Diamond Team',
        'category': 'multimedia',
        'downloads': 1247,
        'rating': 4.8,
        'functions': [
            {'name': 'play_sound', 'description': 'Play an audio file'},
            {'name': 'generate_tone', 'description': 'Generate a tone at specified frequency'},
            {'name': 'set_volume', 'description': 'Set the global audio volume'}
        ]
    },
    'gamedev': {
        'name': 'gamedev',
        'version': '2.1.0',
        'description': '🎮 Diamond Game Development Kit - Sprites, physics, collision, scenes',
        'author': 'Diamond Team',
        'category': 'gamedev',
        'downloads': 2156,
        'rating': 4.9,
        'functions': [
            {'name': 'create_sprite', 'description': 'Create game sprite'},
            {'name': 'move_sprite', 'description': 'Move sprite with velocity'},
            {'name': 'check_collision', 'description': 'Advanced collision detection'},
            {'name': 'apply_gravity', 'description': 'Apply physics simulation'}
        ]
    },
    'crypto': {
        'name': 'crypto',
        'version': '1.0.0',
        'description': '🔐 Cryptography module - Encryption, hashing, digital signatures',
        'author': 'Diamond Team',
        'category': 'security',
        'downloads': 892,
        'rating': 4.7,
        'functions': [
            {'name': 'hash_sha256', 'description': 'Generate SHA-256 hash'},
            {'name': 'encrypt_simple', 'description': 'Simple encryption'},
            {'name': 'generate_random', 'description': 'Generate random strings'}
        ]
    },
    'network': {
        'name': 'network',
        'version': '1.2.0',
        'description': '🌐 Advanced networking for Diamond - TCP/UDP sockets, servers, clients',
        'author': 'Diamond Team',
        'category': 'networking',
        'downloads': 1543,
        'rating': 4.6,
        'functions': [
            {'name': 'tcp_connect', 'description': 'Connect to TCP server'},
            {'name': 'tcp_listen', 'description': 'Start TCP server'},
            {'name': 'udp_send', 'description': 'Send UDP packet'}
        ]
    },
    'ai': {
        'name': 'ai',
        'version': '0.9.0',
        'description': '🧠 Machine Learning for Diamond - Neural networks, decision trees, clustering',
        'author': 'Diamond Team',
        'category': 'ai',
        'downloads': 634,
        'rating': 4.5,
        'functions': [
            {'name': 'create_network', 'description': 'Create neural network'},
            {'name': 'train_model', 'description': 'Train ML model'},
            {'name': 'predict', 'description': 'Make predictions'}
        ]
    },
    'database': {
        'name': 'database',
        'version': '1.5.0',
        'description': '🗄️ Database connectivity - SQLite, MySQL, PostgreSQL support',
        'author': 'Diamond Team',
        'category': 'database',
        'downloads': 1098,
        'rating': 4.8,
        'functions': [
            {'name': 'db_connect', 'description': 'Connect to database'},
            {'name': 'db_query', 'description': 'Execute SQL query'},
            {'name': 'db_close', 'description': 'Close database connection'}
        ]
    }
}

class BlueDemo:
    def __init__(self):
        self.modules_dir = Path("modules")
        self.extensions_dir = Path("extensions")
        self.modules_dir.mkdir(exist_ok=True)
        self.extensions_dir.mkdir(exist_ok=True)

    def install_module(self, module_name):
        print(f"🔍 Searching for module '{module_name}'...")
        
        if module_name not in LOCAL_MODULES:
            print(f"❌ Module '{module_name}' not found in registry")
            self.suggest_similar_modules(module_name)
            return False
        
        module_info = LOCAL_MODULES[module_name]
        print(f"📦 Found module: {module_info['name']} v{module_info['version']}")
        print(f"📝 Description: {module_info['description']}")
        
        # Create module file
        module_file = self.modules_dir / f"{module_name}.c"
        module_content = self.get_module_content(module_name)
        
        print("⬇️ Downloading module files...")
        with open(module_file, 'w') as f:
            f.write(module_content)
        print(f"✅ Downloaded: {module_name}.c")
        
        print(f"🎉 Successfully installed '{module_name}'!")
        print(f"💡 Include in your Diamond code with: use {module_name};")
        return True

    def search_modules(self, query):
        print(f"🔍 Searching for '{query}'...")
        
        matches = []
        for name, module in LOCAL_MODULES.items():
            if (query.lower() in name.lower() or 
                query.lower() in module['description'].lower() or
                query.lower() in module['category'].lower()):
                matches.append(module)
        
        if not matches:
            print("📭 No modules found matching your search")
            return
        
        print(f"Found {len(matches)} modules:")
        print("-" * 60)
        
        for module in matches:
            print(f"📦 {module['name']} v{module['version']}")
            print(f"   {module['description']}")
            print(f"   Downloads: {module['downloads']} | Rating: {module['rating']}⭐")
            print()

    def list_installed(self):
        print("📦 Installed Diamond Modules:")
        print("-" * 40)
        
        modules = list(self.modules_dir.glob("*.c"))
        if not modules:
            print("📭 No modules installed")
            print("💡 Try: blue install <module_name>")
            return
        
        for module_file in modules:
            module_name = module_file.stem
            size = module_file.stat().st_size
            print(f"✅ {module_name} ({size} bytes)")

    def get_module_info(self, module_name):
        if module_name not in LOCAL_MODULES:
            print(f"❌ Module '{module_name}' not found")
            return
        
        module = LOCAL_MODULES[module_name]
        print(f"📦 {module['name']} v{module['version']}")
        print(f"👤 Author: {module['author']}")
        print(f"📝 Description: {module['description']}")
        print(f"⬇️ Downloads: {module['downloads']}")
        print(f"⭐ Rating: {module['rating']}/5")
        print(f"🏷️ Category: {module['category']}")
        
        if 'functions' in module:
            print(f"🔧 Available functions:")
            for func in module['functions']:
                print(f"   - {func['name']}: {func['description']}")

    def upload_extension(self, extension_path):
        ext_file = Path(extension_path)
        
        if not ext_file.exists():
            print(f"❌ File not found: {extension_path}")
            return False
        
        if ext_file.suffix != '.c':
            print("❌ Only .c files can be uploaded as extensions")
            return False
        
        print(f"📤 Simulating upload of extension: {ext_file.name}")
        
        # Copy to extensions directory
        dest_file = self.extensions_dir / ext_file.name
        with open(ext_file, 'r') as src, open(dest_file, 'w') as dst:
            dst.write(src.read())
        
        print(f"🎉 Extension '{ext_file.name}' uploaded successfully!")
        print(f"📁 Stored in: {dest_file}")
        return True

    def suggest_similar_modules(self, module_name):
        suggestions = []
        for name in LOCAL_MODULES.keys():
            if name.startswith(module_name[:2]) or module_name[:3] in name:
                suggestions.append(name)
        
        if suggestions:
            print("💡 Did you mean one of these?")
            for suggestion in suggestions[:3]:
                print(f"   - {suggestion}")

    def get_module_content(self, module_name):
        if module_name == 'audio':
            return open('modules/audio.c', 'r').read() if Path('modules/audio.c').exists() else "// Audio module content"
        elif module_name == 'gamedev':
            return open('modules/gamedev.c', 'r').read() if Path('modules/gamedev.c').exists() else "// Game dev module content"
        elif module_name == 'crypto':
            return open('modules/crypto.c', 'r').read() if Path('modules/crypto.c').exists() else "// Crypto module content"
        else:
            return f"// {module_name} module content\n// This is a demo module for {module_name}\n"

def main():
    if len(sys.argv) < 2:
        print("Blue Package Manager for Diamond Programming Language (Demo Mode)")
        print("================================================================")
        print("Usage:")
        print("  python3 blue_demo.py install <module>     - Install a module")
        print("  python3 blue_demo.py search <query>       - Search for modules")
        print("  python3 blue_demo.py list                 - List installed modules")
        print("  python3 blue_demo.py upload <file.c>      - Upload an extension")
        print("  python3 blue_demo.py info <module>        - Get module information")
        print("")
        print("Available surprise modules:")
        for name, module in LOCAL_MODULES.items():
            print(f"  📦 {name} - {module['description']}")
        return

    blue = BlueDemo()
    command = sys.argv[1]

    if command == "install" and len(sys.argv) >= 3:
        module_name = sys.argv[2]
        blue.install_module(module_name)
    
    elif command == "search" and len(sys.argv) >= 3:
        query = " ".join(sys.argv[2:])
        blue.search_modules(query)
    
    elif command == "list":
        blue.list_installed()
    
    elif command == "upload" and len(sys.argv) >= 3:
        extension_path = sys.argv[2]
        blue.upload_extension(extension_path)
    
    elif command == "info" and len(sys.argv) >= 3:
        module_name = sys.argv[2]
        blue.get_module_info(module_name)
    
    else:
        print("❌ Invalid command. Use without arguments to see usage.")

if __name__ == "__main__":
    main()