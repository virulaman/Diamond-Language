# 🚀 Quick Start Guide

## One-Command Installation

### Linux/macOS
```bash
# Download and install
git clone https://github.com/virulaman/Diamond-Language.git
cd Diamond-Language
./install.sh
```

### Cross-Platform (Python)
```bash
# Download and install
git clone https://github.com/virulaman/Diamond-Language.git
cd Diamond-Language  
python3 setup.py
```

### Windows
```cmd
# Download and install
git clone https://github.com/virulaman/Diamond-Language.git
cd Diamond-Language
python setup.py
```

## What Happens

1. **Dependency Check** - Verifies GCC and Make are installed
2. **Clean Build** - Removes any previous builds
3. **Compile** - Builds the Diamond Language compiler from source
4. **Test** - Runs a test program to verify everything works
5. **Install** - Optionally installs system-wide

## After Installation

### Run Your First Program
```bash
# Create hello.dmo
echo 'use stdlib;
int main() {
    show.txt("Hello, Diamond World!");
    return 0;
}' > hello.dmo

# Run it
./dmo hello.dmo
```

### Use the Package Manager
```bash
./blue list                    # See available packages
./blue install audio          # Install audio package
./blue info gamedev           # Get package information
```

### Try Examples
```bash
./dmo examples/hello.dmo       # Basic hello world
./dmo examples/graphics_demo.dmo   # Graphics showcase
./dmo examples/math_demo.dmo   # Math operations
```

## If Something Goes Wrong

### Build Dependencies Missing
```bash
# Ubuntu/Debian
sudo apt-get install build-essential

# CentOS/RHEL  
sudo yum groupinstall "Development Tools"

# macOS
xcode-select --install
```

### Manual Build
```bash
make clean
make all
./dmo examples/hello.dmo
```

## Next Steps

1. Read `README.md` for complete documentation
2. Check `examples/` folder for sample programs
3. Visit the web interface for package management
4. Start coding in Diamond Language!

The installer automatically handles everything - just run one command and start programming!