#!/usr/bin/env python3
"""
Diamond Language Setup Script
Cross-platform installer for Diamond Language compiler
"""

import os
import sys
import subprocess
import platform
import shutil
from pathlib import Path

def run_command(cmd, cwd=None):
    """Run a command and return success status"""
    try:
        result = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
        return result.returncode == 0, result.stdout, result.stderr
    except Exception as e:
        return False, "", str(e)

def check_dependencies():
    """Check for required build dependencies"""
    print("🔍 Checking dependencies...")
    
    # Check for GCC
    success, _, _ = run_command("gcc --version")
    if not success:
        print("❌ GCC compiler not found")
        if platform.system() == "Windows":
            print("   Install MinGW or Visual Studio Build Tools")
        elif platform.system() == "Darwin":
            print("   Install Xcode Command Line Tools: xcode-select --install")
        else:
            print("   Install build tools: sudo apt-get install build-essential")
        return False
    
    # Check for Make
    success, _, _ = run_command("make --version")
    if not success:
        print("❌ Make not found")
        print("   Install build tools for your platform")
        return False
    
    print("✅ Dependencies found")
    return True

def build_compiler():
    """Build the Diamond Language compiler"""
    print("🔨 Building Diamond Language compiler...")
    
    # Clean previous builds
    print("🧹 Cleaning previous builds...")
    run_command("make clean")
    
    # Build
    success, stdout, stderr = run_command("make all")
    if success:
        print("✅ Build successful!")
        return True
    else:
        print("❌ Build failed!")
        print("Error output:", stderr)
        return False

def test_installation():
    """Test the compiled binary"""
    print("🧪 Testing installation...")
    
    # Check if binary exists
    binary_name = "dmo.exe" if platform.system() == "Windows" else "dmo"
    if not os.path.exists(binary_name):
        print(f"❌ Compiler binary '{binary_name}' not found")
        return False
    
    print(f"✅ Diamond compiler ({binary_name}) created successfully")
    
    # Test with hello world if it exists
    if os.path.exists("examples/hello.dmo"):
        print("🔍 Running test program...")
        success, _, _ = run_command(f"./{binary_name} examples/hello.dmo")
        if success:
            print("✅ Test program executed successfully")
        else:
            print("⚠️  Test program failed, but compiler was built")
    
    return True

def install_system_wide():
    """Install Diamond Language system-wide"""
    print("🔧 Installing system-wide...")
    
    if platform.system() == "Windows":
        print("⚠️  System-wide installation not implemented for Windows")
        print("📍 Use the compiler from current directory: .\\dmo.exe")
        return False
    
    try:
        # Create directories
        os.makedirs("/usr/local/bin", exist_ok=True)
        os.makedirs("/usr/local/share/diamond", exist_ok=True)
        os.makedirs("/usr/local/share/diamond/examples", exist_ok=True)
        
        # Copy binary
        shutil.copy2("dmo", "/usr/local/bin/dmo")
        os.chmod("/usr/local/bin/dmo", 0o755)
        
        # Copy examples
        if os.path.exists("examples"):
            shutil.copytree("examples", "/usr/local/share/diamond/examples", dirs_exist_ok=True)
        
        # Copy Blue package manager
        if os.path.exists("blue"):
            shutil.copy2("blue", "/usr/local/bin/blue")
            os.chmod("/usr/local/bin/blue", 0o755)
        
        if os.path.exists("blue_package_manager.py"):
            shutil.copy2("blue_package_manager.py", "/usr/local/share/diamond/blue_package_manager.py")
        
        print("✅ Diamond Language installed to /usr/local/bin/dmo")
        print("✅ Examples installed to /usr/local/share/diamond/examples/")
        print("✅ Blue package manager installed to /usr/local/bin/blue")
        return True
        
    except PermissionError:
        print("❌ Permission denied. Try running with sudo:")
        print("   sudo python3 setup.py")
        return False
    except Exception as e:
        print(f"❌ Installation failed: {e}")
        return False

def main():
    print("🔷 Diamond Language Setup")
    print("=" * 40)
    
    # Check if we're in the right directory
    if not (os.path.exists("main.c") and os.path.exists("Makefile")):
        print("❌ Error: Please run this script from the Diamond Language source directory")
        sys.exit(1)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Build compiler
    if not build_compiler():
        sys.exit(1)
    
    # Test installation
    if not test_installation():
        sys.exit(1)
    
    # Ask about system-wide installation
    if platform.system() != "Windows":
        try:
            response = input("\n📦 Install Diamond Language system-wide? (y/N): ").strip().lower()
            if response in ['y', 'yes']:
                install_system_wide()
            else:
                print("📍 Diamond Language compiler available as ./dmo in current directory")
        except KeyboardInterrupt:
            print("\n📍 Diamond Language compiler available as ./dmo in current directory")
    else:
        print("📍 Diamond Language compiler available as .\\dmo.exe in current directory")
    
    print("\n🎉 Setup Complete!")
    print("=" * 40)
    print("📖 Usage:")
    if platform.system() == "Windows":
        print("   .\\dmo.exe examples\\hello.dmo    # Run example program")
        print("   .\\dmo.exe myprogram.dmo        # Run your program")
    else:
        print("   ./dmo examples/hello.dmo      # Run example program")
        print("   ./dmo myprogram.dmo          # Run your program")
        print("   ./blue list                  # List available packages")
        print("   ./blue install audio        # Install packages")
    print("\n📚 Documentation: README.md")
    print("🌐 Web interface: https://github.com/virulaman/Diamond-Language")

if __name__ == "__main__":
    main()