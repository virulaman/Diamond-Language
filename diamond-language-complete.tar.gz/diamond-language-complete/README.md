# Diamond Programming Language

A modern programming language with C#-like syntax, powerful graphics capabilities, and modular design.

## Quick Start

### Automatic Installation (Recommended)
```bash
# Clone and install automatically
git clone https://github.com/virulaman/Diamond-Language.git
cd Diamond-Language
./install.sh
```

### Cross-Platform Installation
```bash
# Python-based installer (works on all platforms)
git clone https://github.com/virulaman/Diamond-Language.git
cd Diamond-Language
python3 setup.py
```

### Manual Build
```bash
# Build the compiler manually
make clean && make all

# Run examples
make examples

# Run your own program
./dmo myprogram.dmo
```

### Windows
```cmd
# Automatic setup
python setup.py

# Or manual build
build_windows.bat
dmo.exe examples\hello.dmo
```

## Installation Packages

### Ubuntu/Debian
```bash
sudo dpkg -i dmo-compiler_1.0.0_amd64.deb
```

### From Source
```bash
# Extract the distribution
tar -xzf dmo-compiler-distribution.tar.gz
cd dmo-compiler/
make clean && make all
sudo make install
```

## Language Features

### Basic Syntax
```diamond
use stdlib;

int main() {
    show.txt("Hello, Diamond World!");
    return 0;
}
```

### Graphics Programming
```diamond
use dmo_graphs;

int main() {
    dmo.gr.create.window("Graphics Demo", 800, 600);
    dmo.gr.create.sqr(50, 50, 100, 100, "blue");
    dmo.gr.create.crle(200, 200, 75, "red");
    return 0;
}
```

### HTTP Requests
```diamond
use request;

int main() {
    string response = request.get("https://api.github.com/users/virulaman");
    show.txt(response);
    return 0;
}
```

## Built-in Modules

- **stdlib** - Standard library functions (show.txt, system, cls, clear)
- **dmo_graphs** - Graphics library with SVG output
- **request** - HTTP client for GET/POST requests
- **math** - Mathematical functions (sin, cos, tan, sqrt, pow)

## Blue Package Manager

Diamond includes the Blue package manager for extending functionality:

```bash
blue install audio     # Audio processing
blue install gamedev   # Game development tools  
blue install crypto    # Cryptography functions
blue install network   # Advanced networking
blue install ai        # AI/ML capabilities
blue install database  # Database connectivity
```

## Project Structure

```
├── main.c              # Compiler entry point
├── lexer.c/.h          # Lexical analysis
├── parser.c/.h         # Syntax parsing
├── ast.c/.h            # Abstract Syntax Tree
├── interpreter.c/.h    # Program execution
├── modules.c/.h        # Module system
├── stdlib_funcs.c/.h   # Standard library
├── dmo_graphs.c/.h     # Graphics library
├── examples/           # Sample programs
└── Makefile           # Build system
```

## Examples

The `examples/` directory contains sample programs:

- `hello.dmo` - Basic hello world
- `graphics_demo.dmo` - Graphics showcase
- `modules_demo.dmo` - Module usage
- `math_demo.dmo` - Mathematical operations
- `request_demo.dmo` - HTTP requests
- `advanced_demo.dmo` - Complete feature demo

## Web Interface

For a complete web interface with documentation and package management, visit:
[Diamond Language Web](https://github.com/virulaman/Diamond-Language)

## Building from Source

### Requirements
- GCC compiler with C99 support
- Make build system
- Math library (libm)

### Build Process
```bash
make clean      # Clean previous builds
make all        # Compile the compiler
make examples   # Run example programs
make install    # Install system-wide (requires sudo)
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with example programs
5. Submit a pull request

## License

Open source project. See LICENSE file for details.

## Links

- **Repository**: https://github.com/virulaman/Diamond-Language
- **Documentation**: Complete language reference in web interface
- **Issues**: Report bugs and feature requests on GitHub
- **Blue Package Manager**: Install additional modules and libraries

---

Made with ❤️ for the programming community