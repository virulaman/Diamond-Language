/*
 * DMO Language Module System Header
 * Handles module loading and imports
 */

#ifndef MODULES_H
#define MODULES_H

#include "interpreter.h"

// Module structure
typedef struct Module {
    char* name;
    char* path;
    bool loaded;
    struct Module* next;
} Module;

// Module system context
typedef struct {
    Module* loaded_modules;
    char** search_paths;
    int path_count;
} ModuleSystem;

// Function prototypes
void init_module_system();
void cleanup_module_system();
void init_modules(InterpreterContext* ctx);
bool load_module(const char* module_name, InterpreterContext* ctx);
char* find_module_file(const char* module_name);
void add_search_path(const char* path);
bool is_module_loaded(const char* module_name);
void mark_module_loaded(const char* module_name, const char* path);

// Built-in module loaders
void init_modules(InterpreterContext* ctx);
void load_stdlib_module(InterpreterContext* ctx);
void load_dmo_graphs_module(InterpreterContext* ctx);
void load_request_module(InterpreterContext* ctx);
void load_math_module(InterpreterContext* ctx);

// Request module functions
Value request_get(ASTNode** args, int arg_count, InterpreterContext* ctx);
Value request_post(ASTNode** args, int arg_count, InterpreterContext* ctx);
bool is_request_function(const char* name);
Value call_request_function(const char* name, ASTNode** args, int arg_count, InterpreterContext* ctx);

// Math module functions
Value math_sin(ASTNode** args, int arg_count, InterpreterContext* ctx);
Value math_cos(ASTNode** args, int arg_count, InterpreterContext* ctx);
Value math_tan(ASTNode** args, int arg_count, InterpreterContext* ctx);
Value math_sigmoid(ASTNode** args, int arg_count, InterpreterContext* ctx);
Value math_sqrt(ASTNode** args, int arg_count, InterpreterContext* ctx);
Value math_pow(ASTNode** args, int arg_count, InterpreterContext* ctx);
bool is_math_function(const char* name);
Value call_math_function(const char* name, ASTNode** args, int arg_count, InterpreterContext* ctx);

#endif // MODULES_H
